
import React from 'react';
import { Link } from 'react-router-dom';
export default function Navbar(){
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
      <div className="container">
        <Link className="navbar-brand d-flex align-items-center" to="/"><span className="badge bg-danger me-2">P</span><strong>Pauperrimos</strong></Link>
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item"><Link className="nav-link" to="/catalogo">Catálogo</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/blogs">Blogs</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/nosotros">Nosotros</Link></li>
            <li className="nav-item"><Link className="nav-link btn btn-danger text-white ms-2" to="/login">Entrar</Link></li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
