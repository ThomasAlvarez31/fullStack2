
import React from 'react';
import { Link } from 'react-router-dom';
export default function ProductCard({p, onAdd}){
  return (
    <div className="col">
      <div className="card h-100">
        <img src={p.img} alt={p.name} className="product-img card-img-top" />
        <div className="card-body">
          <h5 className="card-title">{p.name}</h5>
          <p className="card-text text-muted">{p.desc}</p>
          <p className="text-danger fw-bold">${p.price.toLocaleString('es-CL')}</p>
          <div className="d-flex gap-2">
            <button className="btn btn-primary" onClick={()=>onAdd(p.id)}>Añadir</button>
            <Link to={`/producto/${p.id}`} className="btn btn-outline-secondary">Ver</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
