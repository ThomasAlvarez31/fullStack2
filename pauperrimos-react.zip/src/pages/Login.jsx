
import React from 'react';

export default function Login(){
  return (
    <div className="card p-3" style={{maxWidth:480}}>
      <h2>Iniciar sesión</h2>
      <form onSubmit={(e)=>{e.preventDefault(); const em=e.target[0].value; if(em.startsWith('admin@')) localStorage.setItem('rol','admin'); else localStorage.setItem('rol','cliente'); alert('Login simulado'); window.location.href='/' }}>
        <label className="form-label">Correo<input className="form-control" type="email" required /></label>
        <label className="form-label">Contraseña<input className="form-control" type="password" required /></label>
        <button className="btn btn-primary mt-2">Entrar</button>
      </form>
    </div>
  );
}
