
import React, { useEffect, useState } from 'react';
import { getUsers, saveUsers } from '../data/data';

export default function AdminUsuarios(){
  const [users, setUsers] = useState(getUsers());
  const [form, setForm] = useState({name:'',email:'',run:''});

  useEffect(()=>{ const rol = localStorage.getItem('rol'); if(rol !== 'admin'){ alert('Acceso denegado'); window.location.href='/login' } }, []);

  function handleSave(e){ e.preventDefault(); const u = getUsers(); const id = u.length?Math.max(...u.map(x=>x.id))+1:1; u.push({id, name:form.name, email:form.email, run:form.run, role:'cliente'}); saveUsers(u); setUsers(getUsers()); setForm({name:'',email:'',run:''}); alert('Cliente creado'); }
  function handleDelete(id){ if(!confirm('Eliminar cliente?')) return; let u = getUsers().filter(x=>x.id!==id); saveUsers(u); setUsers(getUsers()); }
  return (
    <div className="card p-3">
      <h2>Gestionar Clientes</h2>
      <form onSubmit={handleSave} className="mb-3">
        <div className="row g-2">
          <div className="col"><input className="form-control" placeholder="Nombre" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required /></div>
          <div className="col"><input className="form-control" placeholder="Correo" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required /></div>
        </div>
        <input className="form-control mt-2" placeholder="RUN" value={form.run} onChange={e=>setForm({...form,run:e.target.value})} />
        <button className="btn btn-primary mt-2">Guardar cliente</button>
      </form>
      <h4>Clientes</h4>
      {users.map(u=> <div key={u.id} className="card p-2 mb-2"><strong>{u.name}</strong> - {u.email} <button className="btn btn-sm btn-danger float-end" onClick={()=>handleDelete(u.id)}>Eliminar</button></div>)}
    </div>
  );
}
