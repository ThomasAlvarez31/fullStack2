
import React from 'react';
import { Link } from 'react-router-dom';
import { getProducts } from '../data/data';
import ProductCard from '../components/ProductCard';

export default function Home(){
  const products = getProducts().slice(0,3);
  return (
    <div>
      <div className="row align-items-center mb-4">
        <div className="col-md-7">
          <h1>Electrónica accesible. Calidad profesional.</h1>
          <p className="text-muted">En Pauperrimos encontrarás productos tecnológicos seleccionados pensando en calidad y precio.</p>
          <Link to="/catalogo" className="btn btn-primary">Comprar ahora</Link>
        </div>
        <div className="col-md-5">
          <div className="card p-3">
            <h5>Oferta del día</h5>
            <img src="/assets/placeholder.png" alt="oferta" className="img-fluid rounded mb-2" />
            <p className="mb-1"><strong>Smart Speaker X1</strong></p>
            <p className="text-danger fw-bold">$49.990</p>
            <Link to="/producto/1" className="btn btn-primary">Ver producto</Link>
          </div>
        </div>
      </div>

      <h3>Productos destacados</h3>
      <div className="row row-cols-1 row-cols-md-3 g-3">
        {products.map(p => <ProductCard key={p.id} p={p} onAdd={()=>{alert('Usa catálogo para añadir')}} />)}
      </div>
    </div>
  );
}
