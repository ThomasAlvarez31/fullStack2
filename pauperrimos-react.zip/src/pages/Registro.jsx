
import React from 'react';

export default function Registro(){
  return (
    <div className="card p-3" style={{maxWidth:680}}>
      <h2>Registro</h2>
      <form onSubmit={(e)=>{e.preventDefault(); alert('Registro simulado: se guardará en admin panel'); window.location.href='/login' }}>
        <label className="form-label">RUN<input className="form-control" required /></label>
        <label className="form-label">Nombre<input className="form-control" required /></label>
        <label className="form-label">Apellidos<input className="form-control" required /></label>
        <label className="form-label">Correo<input className="form-control" type="email" required /></label>
        <label className="form-label">Contraseña<input className="form-control" type="password" required /></label>
        <button className="btn btn-primary mt-2">Crear cuenta</button>
      </form>
    </div>
  );
}
