
import React, { useState } from 'react';
import { getProducts, saveCart, getCart } from '../data/data';
import ProductCard from '../components/ProductCard';

export default function Catalogo(){
  const [productos, setProductos] = useState(getProducts());

  function handleAdd(id){
    const cart = getCart();
    const item = cart.find(i=>i.id===id);
    if(item) item.qty++; else cart.push({id, qty:1});
    saveCart(cart);
    alert('Añadido al carrito (localStorage)');
  }

  return (
    <div>
      <h2>Catálogo</h2>
      <div className="row row-cols-1 row-cols-md-3 g-3">
        {productos.map(p => <ProductCard key={p.id} p={p} onAdd={handleAdd} />)}
      </div>
    </div>
  );
}
