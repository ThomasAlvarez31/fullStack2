
import React, { useEffect, useState } from 'react';
import { getProducts, saveProducts } from '../data/data';

export default function AdminProductos(){
  const [products, setProducts] = useState(getProducts());
  const [form, setForm] = useState({name:'',price:'',desc:'',img:''});

  useEffect(()=>{ const rol = localStorage.getItem('rol'); if(rol !== 'admin'){ alert('Acceso denegado'); window.location.href='/login' } }, []);

  function handleSave(e){ e.preventDefault(); const p = getProducts(); const id = p.length?Math.max(...p.map(x=>x.id))+1:1; p.push({id, name:form.name, price: Number(form.price), desc: form.desc, img: form.img||'/assets/placeholder.png'}); saveProducts(p); setProducts(getProducts()); setForm({name:'',price:'',desc:'',img:''}); alert('Producto creado'); }
  function handleDelete(id){ if(!confirm('Eliminar producto?')) return; let p = getProducts().filter(x=>x.id!==id); saveProducts(p); setProducts(getProducts()); }
  return (
    <div className="card p-3">
      <h2>Gestionar Productos</h2>
      <form onSubmit={handleSave} className="mb-3">
        <div className="row g-2">
          <div className="col"><input className="form-control" placeholder="Nombre" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required /></div>
          <div className="col" style={{maxWidth:160}}><input className="form-control" placeholder="Precio" type="number" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} required /></div>
        </div>
        <textarea className="form-control mt-2" placeholder="Descripción" value={form.desc} onChange={e=>setForm({...form,desc:e.target.value})}></textarea>
        <input className="form-control mt-2" placeholder="Imagen (url)" value={form.img} onChange={e=>setForm({...form,img:e.target.value})} />
        <button className="btn btn-primary mt-2">Guardar</button>
      </form>
      <h4>Productos</h4>
      {products.map(p=> <div key={p.id} className="card p-2 mb-2"><strong>{p.name}</strong> - ${p.price.toLocaleString('es-CL')} <button className="btn btn-sm btn-danger float-end" onClick={()=>handleDelete(p.id)}>Eliminar</button></div>)}
    </div>
  );
}
