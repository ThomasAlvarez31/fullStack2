
import React, { useEffect, useState } from 'react';
import { getCart, saveCart, getProducts } from '../data/data';

export default function Carrito(){
  const [cart, setCart] = useState([]);

  useEffect(()=> setCart(getCart()), []);

  function remove(id){
    let c = getCart().filter(i=>i.id!==id);
    saveCart(c);
    setCart(c);
  }

  function total(){
    const products = getProducts();
    return cart.reduce((s,i)=>{
      const p = products.find(x=>x.id===i.id);
      return s + (p ? p.price * i.qty : 0);
    },0);
  }

  if(cart.length===0) return <p>Carrito vacío</p>;
  return (
    <div>
      <h2>Tu carrito</h2>
      {cart.map(i=>{
        const p = getProducts().find(x=>x.id===i.id);
        return <div key={i.id} className="card mb-2 p-2"><strong>{p.name}</strong> - Cantidad: {i.qty} <button className="btn btn-sm btn-danger ms-2" onClick={()=>remove(i.id)}>Eliminar</button></div>
      })}
      <p className="fw-bold">Total: ${total().toLocaleString('es-CL')}</p>
      <a className="btn btn-primary" href="/contacto">Pagar</a>
    </div>
  );
}
