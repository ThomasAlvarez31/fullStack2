
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getProducts, saveCart, getCart } from '../data/data';

export default function Producto(){
  const { id } = useParams();
  const [p, setP] = useState(null);

  useEffect(()=>{
    const prod = getProducts().find(x=>x.id===Number(id));
    setP(prod);
  },[id]);

  function add(){
    const cart = getCart();
    const item = cart.find(i=>i.id===Number(id));
    if(item) item.qty++; else cart.push({id:Number(id),qty:1});
    saveCart(cart);
    alert('Añadido al carrito');
  }

  if(!p) return <p>Producto no encontrado</p>;
  return (
    <div className="card p-3">
      <div className="row">
        <div className="col-md-5"><img src={p.img} alt={p.name} className="img-fluid rounded" /></div>
        <div className="col-md-7">
          <h2>{p.name}</h2>
          <p className="text-danger fw-bold">${p.price.toLocaleString('es-CL')}</p>
          <p className="text-muted">{p.desc}</p>
          <button className="btn btn-primary" onClick={add}>Añadir al carrito</button>
        </div>
      </div>
    </div>
  );
}
