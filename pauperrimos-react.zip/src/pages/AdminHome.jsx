
import React, { useEffect } from 'react';
export default function AdminHome(){
  useEffect(()=>{ const rol = localStorage.getItem('rol'); if(rol !== 'admin'){ alert('Acceso denegado - admin'); window.location.href = '/login' } }, []);
  return <div className="card p-3"><h2>Panel Admin</h2><p>Bienvenido. Usa el menú para gestionar productos y usuarios.</p></div>
}
